package br.edu.umfg.exerciciosAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExerciciosApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExerciciosApiApplication.class, args);
	}

}
